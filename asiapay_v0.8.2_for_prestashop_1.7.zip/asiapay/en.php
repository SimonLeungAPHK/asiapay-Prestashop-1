<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{asiapay}prestashop>asiapay_b7225422aba2957386105825dc2461db'] = 'PayDollar/PesoPay/SiamPay Payment Service';

$_MODULE['<{asiapay}prestashop>payment_b7225422aba2957386105825dc2461db'] = 'PayDollar/PesoPay/SiamPay Payment Service';
$_MODULE['<{asiapay}prestashop>payment_4c7c21b7f724eacbab05275a7ad47c03'] = 'Proceed with payment using PayDollar/PesoPay/SiamPay ?';

$_MODULE['<{asiapay}prestashop>payment_execution_b7225422aba2957386105825dc2461db'] = 'PayDollar/PesoPay/SiamPay Payment Service';
$_MODULE['<{asiapay}prestashop>payment_execution_fe052c248fb8c2b8cf08c44f17341c3c'] = 'Order Summary';
$_MODULE['<{asiapay}prestashop>payment_execution_879f6b8877752685a966564d072f498f'] = 'Your shopping cart is empty.';
$_MODULE['<{asiapay}prestashop>payment_execution_eacd06b13e93805f27e889b9fe4049d7'] = 'You have chosen to pay using PayDollar/PesoPay/SiamPay Payment Service.';
$_MODULE['<{asiapay}prestashop>payment_execution_3c4b1bd25e6c7122af4a75d0f74a4c22'] = 'If you are not automatically redirected, click ';
$_MODULE['<{asiapay}prestashop>payment_execution_6c92285fa6d3e827b198d120ea3ac674'] = 'here';

$_MODULE['<{asiapay}prestashop>payment_return_29165718380da01e17ddf829b060dcbc'] = 'Your order has been completed. We are preparing to send its product immediately.';
$_MODULE['<{asiapay}prestashop>payment_return_86e836b80aa0354ea7a4701ef04d4822'] = 'For any questions or for further information, please contact our '; 
$_MODULE['<{asiapay}prestashop>payment_return_64430ad2835be8ad60c59e7d44e4b0b1'] = 'customer support';
$_MODULE['<{asiapay}prestashop>payment_return_c32dbea999199df3623663d2b7a989c3'] = 'We noticed a problem with your order. If you think this is an error, you can contact our ';